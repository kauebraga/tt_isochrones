#' OpenTripPlanner of R
#'
#' @description
#' The goal of OpenTripPlanner for R is to provide a simple R interface
#' to OpenTripPlanner (OTP).
#' The OTP is a multimodal trip planning service.
#' @keywords routing transport mulitmodal opentripplanner
"_PACKAGE"
